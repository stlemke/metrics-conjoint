<!--Project-Logo, Partner-Logos, Imprint-->
<img src="img/metrics.png" alt="metrics Logo" height="90" style="float:left;margin-left:10px;margin-top:10px">
<table style="float:right;margin-top:5px">
	<tr>
		<td style="padding:5px;text-align:center">
			<img src="img/gesis-logo.gif" alt="Partner Logo" height="33">
		</td>
		<td style="padding:5px;text-align:center">
			<img src="img/logo-zbw.jpg" alt="Partner Logo" height="24">
		</td>
	</tr>
	<tr>
		<td style="padding:5px;text-align:center">
			<img src="img/vzg.png" alt="Partner Logo" height="33">
		</td>
		<td style="padding:5px;text-align:center">
			<img src="img/sub-logo.png" alt="Partner Logo" height="22">
		</td>
	</tr>
</table>
<br><br><br><br><br>